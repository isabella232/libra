package javapack;

public class TestClass {

}
