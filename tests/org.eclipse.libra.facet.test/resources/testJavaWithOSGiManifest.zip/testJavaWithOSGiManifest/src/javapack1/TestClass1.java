package javapack1;

public class TestClass1 {

}
